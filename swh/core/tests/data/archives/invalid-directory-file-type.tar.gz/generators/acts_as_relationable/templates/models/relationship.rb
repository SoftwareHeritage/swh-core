class Relationship < ActiveRecord::Base
  acts_as_relationable
end